# Bootstrap-5-Slider - HTML5 & CSS3

Responsive carousel built with the latest Bootstrap 5. A carousel is a slideshow cycling through different elements such as photos, videos, or text. Many examples and easy tutorials. A slideshow component for cycling through elements—images or slides of text—like a carousel.
