document.addEventListener('DOMContentLoaded', () => {
    const carouselElement = document.querySelector('#carousel');
  
    // Configura o carrossel para trocar a cada 30 segundos
    const carousel = new bootstrap.Carousel(carouselElement, {
      interval: 30000, // 30 segundos
      ride: 'carousel' // Inicia automaticamente
    });
  });
  